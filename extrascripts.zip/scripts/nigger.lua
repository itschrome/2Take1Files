humpback = function(feat)
	if feat.on then
    local hash
    hash = 0x0d7114c9

	streaming.request_model(hash)
	while(not streaming.has_model_loaded(hash))
	do
		system.wait(0)
	end
	
	player.set_player_model(hash)
	streaming.set_model_as_no_longer_needed(hash)

	return HANDLER_CONTINUE
end

function main()
	
    menu.add_feature("test", "action", 0, humpback)

end

main()