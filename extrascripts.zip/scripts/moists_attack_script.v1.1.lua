local lester = {}
local boobs = {}
local lesveh = {}
local vehtype = {"Oppressor","Oppressor2"}
local wpn = {0x958A4A8F, 0x6D544C99}
local wpnsel
local runs = 0
local pid
local pname
local myplygrp

function playersid(feat)
    pid = feat.value_i
    wpnsel = wpn[2]
    if player.get_player_scid(pid) and pid == -1 then

        pname = tostring("PID Target Not Valid or Selected")
    else
        plygrp = player.get_player_group(pid)
        myplygrp = player.get_player_group(player.player_id())
        pname = tostring(player.get_player_name(pid))
        ui.notify_above_map("Session Player ID set to: " .. pid .. "\n" .. pname .. "\nTarget Player Group ID: " .. plygrp.."\nMy Player Group ID: "..myplygrp, "Player ID Selection", 212)
    end
    return HANDLER_POP
end


op_lester = function(attack, t, mod_id, posz)
	local modd = tonumber(mod_id)
    local pedp = player.get_player_ped(pid)
    local pos = player.get_player_coords(pid)
    pos.x = pos.x + 5
    pos.y = pos.y + 5

	pos.z = pos.z + posz

    local model = gameplay.get_hash_key("ig_lestercrest_2")
    streaming.request_model(model)

    while (not streaming.has_model_loaded(model)) do
        return HANDLER_CONTINUE
    end

    local i = #lester + 1
    lester[i] = ped.create_ped(29, model, pos, pos.z, true, false)

    streaming.set_model_as_no_longer_needed(model)

    local vehhash = gameplay.get_hash_key(vehtype[t])

    streaming.request_model(vehhash)
    while (not streaming.has_model_loaded(vehhash)) do
        return HANDLER_CONTINUE
    end

    local y = #lesveh + 1
    lesveh[y] = vehicle.create_vehicle(vehhash, pos, pos.z, true, false)
	vehicle.set_vehicle_mod_kit_type(lesveh[y], 0)
	vehicle.get_vehicle_mod(lesveh[y], 10)
	vehicle.set_vehicle_mod(lesveh[y], 10, modd, false)
	ui.add_blip_for_entity(lesveh[y])
    vehicle.set_vehicle_on_ground_properly(lesveh[y])
    entity.set_entity_god_mode(lesveh[y], true)
    vehicle.set_vehicle_doors_locked(lesveh[y], 5)

    network.request_control_of_entity(lesveh[y])

    ped.set_ped_combat_attributes(lester[i], 46, true)

    ped.set_ped_combat_attributes(lester[i], 52, true)

    ped.set_ped_combat_attributes(lester[i], 1, true)

    ped.set_ped_combat_attributes(lester[i], 2, true)

    ped.set_ped_combat_range(lester[i], 2)

    ped.set_ped_combat_ability(lester[i], 2)

    ped.set_ped_combat_movement(lester[i], 2)
    ped.set_ped_into_vehicle(lester[i], lesveh[y], -1)
    if ai.task_vehicle_drive_wander(lester[i], lesveh[y], 180, 262144) then
        return HANDLER_CONTINUE
    end

    vehicle.set_vehicle_doors_locked(lesveh[y], 6)

    vehicle.set_vehicle_on_ground_properly(lesveh[y])
    vehicle.set_vehicle_doors_locked(lesveh[y], 2)
    entity.set_entity_coords_no_offset(lesveh[y], pos)

    vehicle.set_vehicle_on_ground_properly(lesveh[y])

    if attack == true then
	ai.task_combat_ped(lester[i], pedp, 0, 16)
    end
	vehicle.set_vehicle_on_ground_properly(lesveh[y])

    streaming.set_model_as_no_longer_needed(vehhash)

end

apc_lester = function(attack)
    local pedp = player.get_player_ped(pid)
    local pos = player.get_player_coords(pid)
    pos.x = pos.x + 5
    pos.y = pos.y + 5

    local model = gameplay.get_hash_key("ig_lestercrest_2")
    local vehhash = gameplay.get_hash_key("apc")
    streaming.request_model(model)

    while (not streaming.has_model_loaded(model)) do
        return HANDLER_CONTINUE
    end

    local i = #lester + 1
    lester[i] = ped.create_ped(29, model, pos, pos.z, true, false)



    streaming.request_model(vehhash)
    while (not streaming.has_model_loaded(vehhash)) do
        return HANDLER_CONTINUE
    end

    local y = #lesveh + 1
    lesveh[y] = vehicle.create_vehicle(vehhash, pos, pos.z, true, false)
	ui.add_blip_for_entity(lesveh[y])
    ped.set_ped_into_vehicle(lester[i], lesveh[y], -1)	
    vehicle.set_vehicle_on_ground_properly(lesveh[y])
    entity.set_entity_god_mode(lesveh[y], true)
    vehicle.set_vehicle_doors_locked(lesveh[y], 5)
	
    vehicle.get_vehicle_mod(lesveh[y], 10)
    vehicle.set_vehicle_mod(lesveh[y], 10, 0, false)
    network.request_control_of_entity(lesveh[y])

    ped.set_ped_combat_attributes(lester[i], 46, true)

    ped.set_ped_combat_attributes(lester[i], 52, true)

    ped.set_ped_combat_attributes(lester[i], 1, true)

    ped.set_ped_combat_attributes(lester[i], 2, true)

    ped.set_ped_combat_range(lester[i], 2)

    ped.set_ped_combat_ability(lester[i], 2)

    ped.set_ped_combat_movement(lester[i], 2)

    if ai.task_vehicle_drive_wander(lester[i], lesveh[y], 180, 262144) then
        return HANDLER_CONTINUE
    end
    local i = #lester + 1
	
    lester[i] = ped.create_ped(29, model, pos, pos.z, true, false)

    ped.set_ped_combat_attributes(lester[i], 52, true)
    ped.set_ped_combat_attributes(lester[i], 1, true)
    ped.set_ped_combat_attributes(lester[i], 46, true)
    ped.set_ped_combat_attributes(lester[i], 2, true)
    ped.set_ped_combat_range(lester[i], 2)
    ped.set_ped_combat_ability(lester[i], 2)
    ped.set_ped_combat_movement(lester[i], 2)

    ped.set_ped_into_vehicle(lester[i], lesveh[y], 0)

    vehicle.set_vehicle_doors_locked(lesveh[y], 6)

    pos = player.get_player_coords(pid)

    pos.x = pos.x + 8
    pos.y = pos.y + 8
    vehicle.set_vehicle_on_ground_properly(lesveh[y])
    -- vehicle.set_vehicle_doors_locked(lesveh[y], 2)
    entity.set_entity_coords_no_offset(lesveh[y], pos)
    vehicle.set_vehicle_on_ground_properly(lesveh[y])
	
	if attack == true then
    ai.task_combat_ped(lester[i], pedp, 0, 16)
	end

 
    streaming.set_model_as_no_longer_needed(vehhash)
    streaming.set_model_as_no_longer_needed(model)
end


send_boobs_para = function(feat)
    local pedp = player.get_player_ped(pid)
    local model = 2633130371
    local parachute = 0xfbab5776
    local pos = player.get_player_coords(pid)
    local offset = v3()
    offset.z = 40
    pos.x = pos.x + 5
    pos.y = pos.y + 15

    streaming.request_model(model)

    while not streaming.has_model_loaded(model) do
        system.wait(0)
    end
    local i = #boobs + 1
    boobs[i] = ped.create_ped(5, model, pos + offset, 0, true, false)
    ped.set_ped_can_switch_weapons(boobs[i], true)
    ped.set_ped_combat_attributes(boobs[i], 46, true)
    ped.set_ped_combat_attributes(boobs[i], 52, true)
    ped.set_ped_combat_attributes(boobs[i], 1, true)
    ped.set_ped_combat_attributes(boobs[i], 2, true)
    ped.set_ped_combat_range(boobs[i], 2)
    ped.set_ped_combat_ability(boobs[i], 2)
    ped.set_ped_combat_movement(boobs[i], 2)

    ui.add_blip_for_entity(boobs[i])
    entity.set_entity_god_mode(boobs[i], true)
    weapon.give_delayed_weapon_to_ped(boobs[i], parachute, 1, 0)
    system.wait(0)

    ai.task_parachute_to_target(boobs[i], pos)
    system.wait(10000)
    weapon.give_delayed_weapon_to_ped(boobs[i], wpnsel, 1, 1)

    streaming.set_model_as_no_longer_needed(model)

    system.wait(1000)

    ai.task_combat_ped(boobs[i], pedp, 0, 16)
end

send_lester_para = function(feat)
    local pedp = player.get_player_ped(pid)
    local model = gameplay.get_hash_key("ig_lestercrest_2")
    local parachute = 0xfbab5776
    local pos = player.get_player_coords(pid)
    local offset = v3()
    offset.z = 40
    pos.x = pos.x + 5
    pos.y = pos.y + 15

    streaming.request_model(model)

    while not streaming.has_model_loaded(model) do
        system.wait(0)
    end
    local i = #lester + 1
    lester[i] = ped.create_ped(5, model, pos + offset, 0, true, false)
	ui.add_blip_for_entity(lester[i])
    entity.set_entity_god_mode(lester[i], true)
    ped.set_ped_can_switch_weapons(lester[i], true)
    ped.set_ped_combat_attributes(lester[i], 46, true)
    ped.set_ped_combat_attributes(lester[i], 52, true)
    ped.set_ped_combat_attributes(lester[i], 1, true)
    ped.set_ped_combat_attributes(lester[i], 2, true)
    ped.set_ped_combat_range(lester[i], 2)
    ped.set_ped_combat_ability(lester[i], 2)
    ped.set_ped_combat_movement(lester[i], 2)
    weapon.give_delayed_weapon_to_ped(lester[i], parachute, 1, 0)
    system.wait(0)
	ai.task_parachute_to_target(lester[i], pos)
    system.wait(10000)
    weapon.give_delayed_weapon_to_ped(lester[i], 0x6D544C99, 1, 1)

    streaming.set_model_as_no_longer_needed(model)

    system.wait(1000)

    ai.task_combat_ped(lester[i], pedp, 0, 16)
end

set_boobs_weapon = function(feat)
    local y = tonumber(feat.value_i)
    wpnsel = wpn[y]
end

send_lester = function(feat)
    local amount = tonumber(feat.value_i)
    for i = 1, amount do
        lesterspawn(i)
    end
end

send_boobs = function(feat)
    local amount = tonumber(feat.value_i)
    for i = 1, amount do
        boobsspawn(i)
    end
end

boobsspawn = function()
    local pedp = player.get_player_ped(pid)
    local model = 2633130371
    local parachute = 0xfbab5776
    local pos = player.get_player_coords(pid)
    local offset = v3()
    local offset_z = math.random(40, 200)
    local headtype = math.random(0, 3)
    offset.z = offset_z
    pos.x = pos.x + 10
    pos.y = pos.y + 20

    streaming.request_model(model)

    while not streaming.has_model_loaded(model) do
        return HANDLER_CONTINUE
        --  system.wait(0)
    end
    local i = #boobs + 1
    boobs[i] = ped.create_ped(5, model, pos + offset, 0, true, false)
	entity.set_entity_god_mode(boobs[i], true)
	ui.add_blip_for_entity(boobs[i])
	ped.set_ped_component_variation(boobs[i], 0, headtype, 0, 0)
    ped.set_ped_component_variation(boobs[i], 2, 0, 0, 0)
    ped.set_ped_component_variation(boobs[i], 3, 1, 0, 0)
    ped.set_ped_component_variation(boobs[i], 4, 1, 0, 0)
    ped.set_ped_component_variation(boobs[i], 8, 1, 0, 0)

    ped.set_ped_can_switch_weapons(boobs[i], true)
    ped.set_ped_combat_attributes(boobs[i], 46, true)
    ped.set_ped_combat_attributes(boobs[i], 52, true)
    ped.set_ped_combat_attributes(boobs[i], 1, true)
    ped.set_ped_combat_attributes(boobs[i], 2, true)
    ped.set_ped_combat_range(boobs[i], 2)
    ped.set_ped_combat_ability(boobs[i], 2)
    ped.set_ped_combat_movement(boobs[i], 2)
	weapon.give_delayed_weapon_to_ped(boobs[i], parachute, 1, 0)
    --   system.wait(0)

    ai.task_parachute_to_target(boobs[i], pos)
end

boobs_task = function(feat)
    local pedp = player.get_player_ped(pid)
    for i = 1, #boobs do
        -- ped.set_ped_as_group_member(boobs[i], myplygrp)
        -- ped.set_ped_relationship_group_hash(boobs[i], 4208871491)
        weapon.give_delayed_weapon_to_ped(boobs[i], wpnsel, 1, 1)
        ai.task_combat_ped(boobs[i], pedp, 0, 16)
    end
    --return HANDLER_CONTINUE
end

del_boobs = function(feat)
    for i = 1, #boobs do
        entity.set_entity_as_no_longer_needed(boobs[i])
        entity.delete_entity(boobs[i])
    end
end

send_boobs = function(feat)
    local amount = tonumber(feat.value_i)
    for i = 1, amount do
        boobsspawn(i)
    end
end

lesterspawn = function()
    local pedp = player.get_player_ped(pid)
    local model = gameplay.get_hash_key("ig_lestercrest_2")
    local parachute = 0xfbab5776
    local pos = player.get_player_coords(pid)
    local offset = v3()
    local offset_z = math.random(40, 200)
    offset.z = offset_z
    pos.x = pos.x + 10
    pos.y = pos.y + 20

    streaming.request_model(model)

    while not streaming.has_model_loaded(model) do
        return HANDLER_CONTINUE
        --  system.wait(0)
    end
    local i = #lester + 1
    lester[i] = ped.create_ped(5, model, pos + offset, 0, true, false)
    entity.set_entity_god_mode(lester[i], true)
	ui.add_blip_for_entity(lester[i])
    ped.set_ped_can_switch_weapons(lester[i], true)
    ped.set_ped_combat_attributes(lester[i], 46, true)
    ped.set_ped_combat_attributes(lester[i], 52, true)
    ped.set_ped_combat_attributes(lester[i], 1, true)
    ped.set_ped_combat_attributes(lester[i], 2, true)
    ped.set_ped_combat_range(lester[i], 2)
    ped.set_ped_combat_movement(lester[i], 2)
	    ped.set_ped_combat_ability(lester[i], 2)
	weapon.give_delayed_weapon_to_ped(lester[i], parachute, 1, 0)

    --   system.wait(0)

    ai.task_parachute_to_target(lester[i], pos)
end

lester_task = function(feat)
    local pedp = player.get_player_ped(pid)
    for i = 1, #lester do
        -- ped.set_ped_as_group_member(lester[i], myplygrp)
        -- ped.set_ped_relationship_group_hash(lester[i], 4208871491)
        weapon.give_delayed_weapon_to_ped(lester[i], 0x6D544C99, 1, 1)
        ai.task_combat_ped(lester[i], pedp, 0, 16)
    end
    --return HANDLER_CONTINUE
end

del_lester = function(feat)
    for i = 1, #lester do
        entity.set_entity_as_no_longer_needed(lester[i])
        entity.delete_entity(lester[i])
		end
		for i = 1, #lesveh do
		entity.set_entity_as_no_longer_needed(lesveh[i])
        entity.delete_entity(lesveh[i])
    end
end

function main()
    local moist = menu.add_feature("Moists Attack Script", "parent", 0)

    local playerseid = menu.add_feature("Select Player ID:", "action_value_i", moist.id, playersid)
    playerseid.threaded = false
    playerseid.max_i = 32
    playerseid.min_i = -1
    playerseid.value_i = -1

    local lesatk = menu.add_feature("Lester Attacker", "parent", moist.id, cb)
    local boob = menu.add_feature("Boobs Attacker", "parent", moist.id, cb)
	local apcv = menu.add_feature("Send in Vehicle", "parent", lesatk.id, cb)
	local apcatk = menu.add_feature("Send 2x Lester in APC Attack", "action", apcv.id, function(feat)
		apc_lester(true)
	end)
	apcatk.threaded = false

	local apcwan = menu.add_feature("Send 2x Lester in APC Wander Streets", "action", apcv.id, function(feat)
		apc_lester(false)
	end)
	apcwan.threaded = false
	
	local op2atk = menu.add_feature("Send Lester on Oppressor MK2 Attack", "action", apcv.id, function(feat)
		op_lester(true, 2, 1, 10)
	end)
	op2atk.threaded = false
	
	local opatk = menu.add_feature("Send Lester on Oppressor Attack", "action", apcv.id, function(feat)
		op_lester(true, 1, 0, 0)
	end)
	opatk.threaded = false

	local opwan = menu.add_feature("Send Lester on Oppressor Wander Streets", "action", apcv.id, function(feat)
		op_lester(false,  1, 0, 0)
	end)
	opwan.threaded = false

    local boobswpnset = menu.add_feature("set Weapon 1:Bat 2:Railgun", "action_value_i", boob.id, set_boobs_weapon)
    boobswpnset.max_i = 2
    boobswpnset.min_i = 1
    boobswpnset.value_i = 1

    local boobs_para = menu.add_feature("Send boobs Parachuting tasked", "action", boob.id, send_boobs_para)

    local boobretask = menu.add_feature("task boobs to Attack", "action", boob.id, boobs_task)
    boobretask.threaded = false

    local boobs_para01 = menu.add_feature("Send 1-20x boobs(s) no task", "action_value_i", boob.id, send_boobs)
    boobs_para01.threaded = false
    boobs_para01.min_i = 1
    boobs_para01.max_i = 20
    boobs_para01.value_i = 1

    local delete = menu.add_feature("delete Spawned boobss", "action", boob.id, del_boobs)
    delete.threaded = false

    local lester_para = menu.add_feature("Send Lester Parachuting tasked", "action", lesatk.id, send_lester_para)

    local retask = menu.add_feature("task Lester to Attack", "action", lesatk.id, lester_task)
    retask.threaded = false

    local lester_para01 = menu.add_feature("Send 1-20x Lesters no task", "action_value_i", lesatk.id, send_lester)
    lester_para01.threaded = false
    lester_para01.min_i = 1
    lester_para01.max_i = 20
    lester_para01.value_i = 1

    local delete = menu.add_feature("delete Spawned Lesters + Vehicles", "action", lesatk.id, del_lester)
    delete.threaded = false
end
main()
