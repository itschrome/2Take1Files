if not package.path:find(os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\scripts\\lib\\?.lua", 1, true) then
	package.path = package.path .. ";" .. os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\scripts\\lib\\?.lua"
end
local globals = require("globals")

ui.notify_above_map("You have a " .. tostring(math.floor(globals.get_player_kd(player.player_id()) * 100) / 100) .. " K/D and " .. globals.get_player_bank(player.player_id()) .. " monies in the bank.", "Globals Example", 213)
