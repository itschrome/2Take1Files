- Download one of the below if you have none of them: 
	winrar: https://www.win-rar.com/download.html?L=0
	7zip: https://www.7-zip.org/

- Extract Kek's menu X.X.X.X.zip 
- Drag "Kek's menu" and "kek_menu_stuff" folder into "Scripts" folder. 
- Replace old kekMenuLibs folder with new one if you're updating from an older version
- You have to replace kekMenuLibs for updated language files too.

Scripts folder is in this path:
	C:\Users\YOURUSERNAME\AppData\Roaming\PopstarDevs\2Take1Menu\scripts\


If the above didn't work or you didn't understand: 

	type windows button + r at the same time
	A little window will pop up, asking you to type in something.
	Type in %appdata%
	Find the folder "PopstarDevs", open it
	Open the "2Take1Menu" folder inside of "PopstarDevs"
	Then, you will see a folder called "Scripts", if there isn't one, just make it.
	Drag "Kek's menu" and "kek_menu_stuff" folder into "Scripts" folder. 
	
That's it! If you still don't understand or something is wrong, send me a message at Discord: kektram#8996.

If you want to suggest a feature, report a bug or get support, join the Kek's menu Discord server:
https://discord.gg/CPSgPz4D7X